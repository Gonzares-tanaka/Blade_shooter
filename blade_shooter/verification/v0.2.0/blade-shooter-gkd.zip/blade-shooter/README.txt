# BLADE / CLOSE QUARTERS 0.2.0

Pyxel製、256×320、60秒生存の縦スクロール試作です。子機版 `../../shooting_1` は変更していません。
危険を避けて自動ショットで削るか、敵の射撃停止に合わせて近づき、その場でブレイドを振るかを試します。
子機、突進、コンボ、成長、アイテム、ボスはありません。

## 遊び方

小型の紫機は通常ショット2発で倒せます。大きな装甲機はショット32発（連続命中で約4.5秒）、斬撃なら1回です。
装甲機の **赤色 / FIRING** は発射中、**青緑 / OPEN** は発射停止中です。停止は2.5秒あります。
残っている弾に気をつけて、敵の中心より約45〜65px下へ近づき、前方を斬ってください。接触するまで近づく必要はありません。
白い刃と青白い軌跡が、そのフレームで刃が通った場所です。刃に触れた弾だけ消します。
自機付近を丸ごと消す判定や、斬った場所に残る弾消し判定はありません。後ろや横から来る弾、敵本体への接触は斬撃中も危険です。
**斬撃中は通常ショットを止めます。** 振り始め0.07秒 → 攻撃0.10秒 → 振り終わり0.24秒の約0.41秒間は新しい味方弾を発射しません。
すでに撃った味方弾は飛び続け、斬撃終了後は自動射撃が再開します。
攻撃・弾消しは攻撃の0.10秒だけ。振り終わりも移動できます。斬って一瞬の穴を開けたら、自分で移動して抜けてください。

自機は16×16、弾に対する判定は中心の白点（半径2px）、敵本体との接触は機体の外周です。
HP3、被弾後1.2秒無敵。斬撃の再使用は1.0秒（ヒットストップを除く）。ゲージはなく、HUDのBLADE / WAITで再使用可否を示します。
60秒生存でクリア。斬撃を一度も使わずにクリアすることもできます。

| 操作 | PC / Webキーボード | Webタッチ | GKD Pixel 2 |
|---|---|---|---|
| 移動 | 十字キー | 画面上をドラッグ（相対移動） | 十字キー |
| 斬撃 | Z（押した瞬間に1回） | ダブルタップ | A（押した瞬間に1回） |
| 開始・即リトライ | Enter / Z | 上の開始・もう一度 | START / A |
| 一時停止・再開 | P（再開はEnterも可） | 上の一時停止・再開 | START |
| 終了 | Esc | タブを閉じる | SELECT → Ports |

通常ショットは自動（斬撃中だけ停止）。ZやAの押しっぱなしでは連続斬撃しません。SELECTはタイトル、停止、結果、ヒットストップ中にも即終了です。
ドラッグは触れた位置へのワープではなく、指の移動量だけ移動します。自機から離れた場所でも操作できます。
一度でも10 CSS pxを越える移動は往復して戻ってもタップにしません。長押し・複数指も斬撃のタップペアから除外します。
仮想十字キー・攻撃ボタンはありません。アプリ切り替えやフォーカス喪失で一時停止します。

## PC起動

Python 3.10以上、Pyxel 2.9.9を使用します。

```powershell
cd blade_shooter
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

`powershell -ExecutionPolicy Bypass -File .\run.ps1` でも起動できます。
このランチャーは専用 `.venv` を優先し、なければ既存子機版の `.venv` を使用します。
今回の開発環境では既存子機版のPython環境を使い、`..\..\shooting_1\.venv\Scripts\python.exe main.py` でも起動確認しています。

## Web / iPhone Safari / GitHub Pages

配布一式は `dist/web/`。ZIPは `dist/blade-shooter-web.zip` です。

```powershell
python -m http.server 8000 --directory dist/web
```

PCは `http://localhost:8000/`、iPhoneは同じLANのPCのIPとポートで開きます。
最初にPyxelの画面をタップして音声を有効にし、上の「開始」を押してください。
ファイルを直接開く方法ではなくHTTPで開きます。初回は読み込みに時間がかかります。
公式Pyxel 2.9.9ランタイムをCDNから読むためインターネット接続が必要です。

GitHub Pagesでは `dist/web/` の**中身全部**をリポジトリの `docs/` にコピーし、コミット・pushして、
Settings → Pages → Deploy from a branch → 使用ブランチの `/docs` を選びます。
既存子機版の公開先に置くときは `docs/blade/` 等の別ディレクトリにコピーすれば両方を残せます。
相対URLなのでリポジトリ配下でも起動できます。公開先リポジトリ未指定のため、今回GitHubへの公開操作はしていません。

## GKD Pixel 2 / PlumOS

`dist/blade-shooter-gkd.zip` を展開し、次の2つを既存のPortsフォルダへ並べてコピーします。

```text
Ports/
  blade-shooter.sh
  blade-shooter/
    main.py
    config.py
    game.py
    view.py
    README.txt
    VERIFICATION.md
```

Portsから `blade-shooter.sh` を起動。**`/storage/pyxel_Python/bin/python3 -u main.py --gkd`** を使用します。
既存子機版と同じ自己位置解決・exec方式です。実行権限が失われた場合は `chmod +x blade-shooter.sh` が必要です。
SELECTでPythonを終了し、ランチャーへ制御を戻します。ログはランチャー横の `blade_shooter_launch.log`。
ログを書けない場合も起動を続行します。Python、OS、既存子機版を書き換えません。
DPAD / A / BACKの割り当ては子機版から継承し、`config.py` の `GKD_INPUTS` で変更できます。
環境変数 `BLADE_SHOOTER_PYTHON` でPythonのパスを上書きできます。

## 調整・再ビルド

すべて **`config.py`** で調整します。変更後は再起動し、配布版へは `python build.py` を実行して反映します。

| 目的 | 設定（初期値） |
|---|---|
| 移動速度 | `PLAYER_SPEED=125` px/秒 |
| 斬撃の外側・内側・幅（支点から） | `BLADE_REACH=60`, `BLADE_INNER=30`, `BLADE_WIDTH=4` px |
| 斬撃の角度 | `BLADE_START_ANGLE=-165`, `BLADE_END_ANGLE=-15` 度（上=-90） |
| 斬撃の威力・待ち時間 | `BLADE_DAMAGE=40`, `BLADE_COOLDOWN=1.0` 秒 |
| 振り始め・攻撃・振り終わり | `BLADE_WINDUP=0.07`, `BLADE_ACTIVE=0.10`, `BLADE_RECOVERY=0.24` 秒 |
| ヒットストップ | `HITSTOP_SECONDS=0.05` 秒（1斬撃につき1回） |
| 通常弾 | `SHOT_INTERVAL=0.14`, `SHOT_DAMAGE=1`, `SHOT_SPEED=300` |
| 敵HP | `SMALL_HP=2`, `ARMOR_HP=32` |
| 敵弾速度 | `ARMOR_BULLET_SPEED=38`, `SMALL_BULLET_SPEED=48` px/秒 |
| 装甲機の射撃・停止時間 | `ARMOR_FIRE_SECONDS=1.65`, `ARMOR_REST_SECONDS=2.5` |
| 出現表 | `SMALL_WAVES`, `ARMOR_WAVES` |
| タッチ感度・誤認防止 | `WEB_TOUCH` |

ステージは固定配置。装甲機は6/17/29/41/51秒に登場し、周囲を別の弾幕で塞がない配置です。
ステージ時計はヒットストップ中も進み、一時停止中は止まります。
子機版の52色パレットを流用し、素材画像は不要です。

0.2.0では支点近くを守り続ける刃を短くし、有効時間を0.12→0.10秒、振り終わりを0.14→0.24秒、再使用を0.5→1.0秒へ調整しました。
威力40・敵HP・敵弾速度・出現表・操作設定は変更していません。判定は回転と自機移動の軌跡を細分して描画と共用します。
段階ごとの調整比較、突破・回避・静止連斬の確認結果は [VERIFICATION.md](VERIFICATION.md) を参照してください。

```powershell
python build.py
python -m unittest discover -s tests -v
node --test tests/test_gestures.cjs
python tests/check_balance.py
```

実際の検証結果と未確認部分は [VERIFICATION.md](VERIFICATION.md) に記載しています。
Windows WebKitでは公式ランタイム単体でも初期化が停止したため、iPhone Safariのゲーム全体の起動は実機確認が必要です。
Pyxelの公式情報: https://github.com/kitao/pyxel
