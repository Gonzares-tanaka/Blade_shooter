"""図形のみで描画。白い扇形と刃が、そのフレームの攻撃判定。"""
import math
import config as C
from game import point_at, blade_outline


class View:
    def __init__(self, pyxel, profile="pc"):
        self.p, self.profile = pyxel, profile

    def center(self, y, text, color=3):
        self.p.text((C.WIDTH-len(text)*4)//2, y, text, color)

    def polygon(self, points, color):
        for i in range(1, len(points)-1):
            self.p.tri(*points[0], *points[i], *points[i+1], color)

    def armor_half(self, x, y, r, side, color):
        self.p.tri(x, y-r, x+side*r, y-r/2, x+side*r, y+r/2, color)
        self.p.tri(x, y-r, x+side*r, y+r/2, x, y+r, color)
        self.p.line(x+side*4, y-r+5, x+side*(r-3), y, 40)
        self.p.line(x+side*4, y+r-5, x+side*(r-3), y, 33)

    def draw(self, g):
        p = self.p
        p.cls(0)
        shake = C.SHAKE_PIXELS*max(0, g.shake/C.SHAKE_SECONDS)
        sx = math.sin(g.world_time*173)*shake
        sy = math.cos(g.world_time*137)*shake
        p.camera(sx, sy)
        for i in range(55):
            x = (i*73+17) % C.WIDTH
            y = (i*47+g.world_time*(12+i%3*7)) % C.HEIGHT
            if y > C.HUD_HEIGHT:
                p.pset(x, y, 1 if i%4 else 25)
        # 動くレーンで縦スクロールを明示。
        for x in (24, 232):
            for i in range(9):
                y = (i*44+g.world_time*30) % C.HEIGHT
                p.line(x, y, x, y+12, 25)
        for b in g.shots:
            p.rect(b.x-1, b.y-4, 2, 8, 40)
        for e in g.enemies:
            if e.kind == "armor":
                color = 3 if e.flash else 6 if e.resting else 11
                self.armor_half(e.x, e.y, e.radius, -1, color)
                self.armor_half(e.x, e.y, e.radius, 1, color)
                p.rect(e.x-4, e.y-5, 8, 10, 25)
                p.line(e.x, e.y-12, e.x, e.y+12, 51 if e.resting else 10)
                p.rect(e.x-12, e.y+e.radius+4, 24, 2, 1)
                p.rect(e.x-12, e.y+e.radius+4, 24*max(0,e.hp)/C.ARMOR_HP, 2, color)
                if C.ARMOR_Y <= e.y and e.age <= C.ARMOR_LIFETIME:
                    p.text(e.x-8 if e.resting else e.x-14, e.y-e.radius-10,
                           "OPEN" if e.resting else "FIRING", 6 if e.resting else 37)
                    if e.resting:
                        p.line(e.x-22, e.y-5, e.x-22, e.y+5, 6)
                        p.line(e.x+22, e.y-5, e.x+22, e.y+5, 6)
            else:
                p.tri(e.x-8, e.y-5, e.x+8, e.y-5, e.x, e.y+8, 3 if e.flash else 13)
                p.line(e.x-5, e.y-3, e.x+5, e.y-3, 35)
                p.pset(e.x, e.y+2, 3)
        for b in g.bullets:
            p.circ(b.x, b.y, C.BULLET_RADIUS, 12)
            p.circ(b.x, b.y, 1, 3)
        for effect in g.effects:
            self.effect(effect)
        # 攻撃中は毎フレーム掃いた領域だけを描く。ヒットストップ中も同じ領域を保持。
        for poly in g.slash_polys:
            self.polygon(poly, 51)
        if g.hp > 0:
            self.player(g)
        p.camera()
        p.rect(0, 0, C.WIDTH, C.HUD_HEIGHT, 0)
        p.line(0, C.HUD_HEIGHT-1, C.WIDTH, C.HUD_HEIGHT-1, 25)
        p.text(8, 4, "HULL", 2)
        for i in range(C.PLAYER_HP):
            p.rect(30+i*9, 4, 6, 7, 6 if i < g.hp else 1)
        p.text(83, 5, "BLADE" if g.cooldown <= 0 else "WAIT", 6 if g.cooldown <= 0 else 2)
        p.text(181, 5, f"{max(0, math.ceil(C.STAGE_SECONDS-g.time)):02d} SEC", 3)
        # 序盤の短いヒントだけ。メーターやスコアは持たない。
        if 5.5 < g.time < 10.5 and g.state == "playing":
            self.center(34, "RED: FIRING / CYAN: OPEN", 40)
        if g.state == "title":
            self.panel(85, 151)
            self.center(101, "B L A D E", 6)
            self.center(119, "CLOSE QUARTERS / 60 SEC", 40)
            self.center(145, "READ THE OPENING.", 3)
            self.center(157, "MOVE CLOSE. CUT ONCE.", 3)
            self.center(181, "AUTO SHOT / NO AUTO DASH", 2)
            hint = "A / START: BEGIN" if self.profile == "gkd" else "ENTER / Z: BEGIN"
            self.center(210, hint, 6)
        elif g.state in ("gameover", "clear", "paused"):
            self.panel(116, 100)
            self.center(137, {"clear":"SURVIVED / 60 SEC", "gameover":"HULL LOST", "paused":"PAUSED"}[g.state],
                        6 if g.state == "clear" else 3)
            self.center(160, "READ. APPROACH. CUT.", 2)
            hint = "START / A: RETRY" if self.profile == "gkd" else "ENTER / Z: RETRY"
            if g.state == "paused":
                hint = "START: RESUME" if self.profile == "gkd" else "P / ENTER: RESUME"
            self.center(190, hint, 6)
        if self.profile == "gkd" and g.state != "playing":
            self.center(303, "SELECT: EXIT TO PORTS", 2)

    def panel(self, y, height):
        self.p.rect(15, y, 226, height, 0)
        self.p.rectb(15, y, 226, height, 33)

    def player(self, g):
        p, x, y = self.p, g.px, g.py
        visible = g.invincible <= 0 or int(g.world_time*20)%2 == 0
        if visible:
            # 機体は外周16x16。左右翼、胴体、コックピット。
            p.tri(x, y-8, x-8, y+7, x+7, y+7, 33)
            p.tri(x, y-8, x-4, y+5, x+3, y+5, 6)
            p.rect(x-1, y-5, 3, 6, 40)
            p.line(x-7, y+5, x-5, y+2, 3)
            p.line(x+6, y+5, x+4, y+2, 3)
            p.line(x-2, y+8, x, y+10+int(g.world_time*40)%3, 10)
        pivot = g.blade_pivot if g.slash_polys else (x, y-4)
        if g.swing < 0:
            # 待機姿勢: 右腕に折りたたんだ刃。攻撃判定なし。
            elbow, hand = (x+10, y), (x+12, y-6)
            tip = (x+16, y-25)
            color = 6 if g.cooldown <= 0 else 1
        else:
            elbow = point_at(*pivot, 8, g.blade_angle-24)
            hand = point_at(*pivot, C.BLADE_INNER, g.blade_angle)
            tip = point_at(*pivot, C.BLADE_REACH, g.blade_angle)
            color = 3 if g.slash_polys else 33
        p.line(x+5, y-1, *elbow, 2)
        p.line(*elbow, *hand, 6)
        p.circ(*elbow, 2, 40)
        p.line(*hand, *tip, color)
        if g.slash_polys:
            self.polygon(blade_outline(*pivot, g.blade_angle), 3)
        p.circ(*hand, 2, 3)
        p.pset(x, y, 3)

    def effect(self, e):
        p, t = self.p, e.age
        if e.kind == "split":
            for side in (-1, 1):
                x, y = e.x+side*t*68, e.y+t*24
                self.armor_half(x, y, e.radius*(1-t), side, 6 if t < 0.2 else 33)
            p.line(e.x-24-t*40, e.y+10, e.x+24+t*40, e.y-10, 3 if t < 0.15 else 6)
        elif e.kind == "impact":
            for i in range(8):
                a, b = point_at(e.x, e.y, 5+t*130, i*45+15), point_at(e.x, e.y, 12+t*180, i*45+15)
                p.line(*a, *b, 3 if t < 0.08 else 10)
        elif e.kind == "spark":
            p.line(e.x-2-t*20, e.y, e.x+2+t*20, e.y, 6)
            p.line(e.x, e.y-2-t*20, e.x, e.y+2+t*20, 3)
        else:
            p.circb(e.x, e.y, 3+t*65, 37 if e.kind == "hurt" else 10)
