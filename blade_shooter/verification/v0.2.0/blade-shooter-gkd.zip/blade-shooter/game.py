"""描画・入力APIに依存しない共通ゲーム。斬撃ポリゴンは描画と判定で共有。"""
from dataclasses import dataclass
import math
import config as C


@dataclass
class Actions:
    x: float = 0
    y: float = 0
    drag_x: float = 0
    drag_y: float = 0
    slash: bool = False
    confirm: bool = False
    pause: bool = False
    focus_lost: bool = False
    quit: bool = False


@dataclass
class Enemy:
    uid: int
    kind: str
    x: float
    y: float
    hp: int
    age: float = 0
    settled: float = 0
    next_fire: float = 0
    flash: float = 0

    @property
    def radius(self):
        return C.ARMOR_RADIUS if self.kind == "armor" else C.SMALL_RADIUS

    @property
    def resting(self):
        return (self.kind == "armor" and self.y >= C.ARMOR_Y and
                self.settled % (C.ARMOR_FIRE_SECONDS+C.ARMOR_REST_SECONDS) >= C.ARMOR_FIRE_SECONDS)


@dataclass
class Bullet:
    x: float
    y: float
    vx: float
    vy: float


@dataclass
class Effect:
    x: float
    y: float
    kind: str
    radius: float = 0
    age: float = 0


def point_at(x, y, radius, degrees):
    angle = math.radians(degrees)
    return x+math.cos(angle)*radius, y+math.sin(angle)*radius


def segment_distance_sq(x, y, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    t = max(0, min(1, ((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy or 1)))
    return (x-a[0]-t*dx)**2+(y-a[1]-t*dy)**2


def polygon_hits_circle(poly, x, y, radius):
    # 凸ポリゴン内部、または辺への距離。描画で使う頂点と完全に共通。
    signs = []
    for a, b in zip(poly, poly[1:]+poly[:1]):
        signs.append((b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]))
        if segment_distance_sq(x, y, a, b) <= radius*radius:
            return True
    return all(v >= 0 for v in signs) or all(v <= 0 for v in signs)


def blade_outline(x, y, angle):
    """刃本体の4頂点。表示と掃引判定の入力を共用する。"""
    a = math.radians(angle)
    nx, ny = -math.sin(a)*C.BLADE_WIDTH/2, math.cos(a)*C.BLADE_WIDTH/2
    near, far = point_at(x, y, C.BLADE_INNER, angle), point_at(x, y, C.BLADE_REACH, angle)
    return ((near[0]-nx, near[1]-ny), (far[0]-nx, far[1]-ny),
            (far[0]+nx, far[1]+ny), (near[0]+nx, near[1]+ny))


def convex_hull(points):
    points = sorted(set(points))
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    halves = []
    for sequence in (points, points[::-1]):
        half = []
        for p in sequence:
            while len(half) >= 2 and cross(half[-2], half[-1], p) <= 0:
                half.pop()
            half.append(p)
        halves.extend(half[:-1])
    return tuple(halves)


def sweep_polygons(x, y, start, end, previous=None):
    # 回転5度・移動4px以下に細分し、移動前後の刃本体をつなぐ。
    # 自機中心や斬撃全体の扇形をまとめて保護する判定は作らない。
    px, py = previous if previous is not None else (x, y)
    n = max(1, math.ceil(abs(end-start)/5), math.ceil(math.hypot(x-px, y-py)/4))
    poses = [blade_outline(px+(x-px)*i/n, py+(y-py)*i/n, start+(end-start)*i/n)
             for i in range(n+1)]
    return [convex_hull(poses[i]+poses[i+1]) for i in range(n)]


def polygon_hits_motion(poly, start, end, radius):
    """同じ短い時間区間の弾移動も掃引し、高速な相対移動を取りこぼさない。"""
    if polygon_hits_circle(poly, *start, radius) or polygon_hits_circle(poly, *end, radius):
        return True
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    for a, b in zip(poly, poly[1:]+poly[:1]):
        if segment_distance_sq(*a, start, end) <= radius*radius:
            return True
        if (max(start[0], end[0]) >= min(a[0], b[0]) and
                max(a[0], b[0]) >= min(start[0], end[0]) and
                max(start[1], end[1]) >= min(a[1], b[1]) and
                max(a[1], b[1]) >= min(start[1], end[1]) and
                cross(start, end, a)*cross(start, end, b) <= 0 and
                cross(a, b, start)*cross(a, b, end) <= 0):
            return True
    return False


class Game:
    def __init__(self):
        self.state = "title"
        self.reset()
        self.state = "title"

    def reset(self):
        self.state = "playing"
        self.time = self.world_time = 0.0
        self.px, self.py = C.WIDTH/2, C.HEIGHT-54
        self.hp, self.invincible = C.PLAYER_HP, 0.0
        self.cooldown, self.swing, self.shot_clock = 0.0, -1.0, 0.0
        self.hitstop = self.shake = 0.0
        self.enemies, self.bullets, self.shots, self.effects = [], [], [], []
        self.slash_polys, self.slash_slices, self.slash_hits = [], [], set()
        self.events, self.done = [], set()
        self.uid = self.slashes = self.blade_kills = self.shot_kills = self.cleared_bullets = 0
        self.swing_hitstop = False
        self.blade_angle = -70.0
        self.blade_pivot = (self.px, self.py-4)

    def spawn(self, kind, x, y=-20):
        self.uid += 1
        enemy = Enemy(self.uid, kind, x, y, C.ARMOR_HP if kind == "armor" else C.SMALL_HP)
        self.enemies.append(enemy)
        return enemy

    def start_slash(self):
        if self.cooldown > 1e-6 or self.swing >= 0:
            return False
        self.swing, self.cooldown = 0.0, C.BLADE_COOLDOWN
        self.slash_hits.clear()
        self.swing_hitstop = False
        self.slashes += 1
        self.events.append("swing")
        return True

    def damage_enemy(self, enemy, amount, blade=False):
        enemy.hp -= amount
        enemy.flash = 0.07
        if enemy.hp <= 0:
            self.effects.append(Effect(enemy.x, enemy.y, "split" if blade else "pop", enemy.radius))
            if blade:
                self.blade_kills += 1
            else:
                self.shot_kills += 1
        if blade:
            self.effects.append(Effect(enemy.x, enemy.y, "impact", enemy.radius))
            self.shake = C.SHAKE_SECONDS
            self.events.append("cut")
            if not self.swing_hitstop:
                self.hitstop = C.HITSTOP_SECONDS
                self.swing_hitstop = True

    def step(self, dt, action=None):
        action = action or Actions()
        self.events = []
        if action.focus_lost and self.state == "playing":
            self.state = "paused"
            return
        if self.state in ("title", "gameover", "clear"):
            if action.confirm or action.slash:
                self.reset()
                self.events.append("start")
            return
        if action.pause or (action.confirm and self.state == "paused"):
            self.state = "playing" if self.state == "paused" else "paused"
            return
        if self.state == "paused":
            return
        self.time = min(C.STAGE_SECONDS, self.time+dt)
        if self.time >= C.STAGE_SECONDS-1e-7:
            self.time = C.STAGE_SECONDS
            self.state = "clear"
            self.events.append("clear")
            return
        if self.hitstop > 0:
            self.hitstop = max(0, self.hitstop-dt)
            return
        self.world_time += dt
        self.shake = max(0, self.shake-dt)
        self.invincible = max(0, self.invincible-dt)
        self.cooldown = max(0, self.cooldown-dt)
        previous_pivot = (self.px, self.py-4)
        length = max(1.0, math.hypot(action.x, action.y))
        self.px = max(8, min(C.WIDTH-8, self.px+action.x/length*C.PLAYER_SPEED*dt+action.drag_x))
        self.py = max(C.HUD_HEIGHT+8, min(C.HEIGHT-8, self.py+action.y/length*C.PLAYER_SPEED*dt+action.drag_y))
        if action.slash:
            self.start_slash()
        # 終了するフレームも含め、振り始めから振り終わりまでは新規発射しない。
        shot_blocked = self.swing >= 0
        self.schedule()
        previous_enemies = {e.uid: (e.x, e.y) for e in self.enemies}
        self.update_enemies(dt)
        self.update_blade(dt, previous_pivot, previous_enemies)
        # 停止分を溜めて連射しない。発射済みの弾はこの下で通常どおり更新する。
        self.shot_clock -= dt
        if shot_blocked:
            self.shot_clock = max(0, self.shot_clock)
        elif self.shot_clock <= 0:
            self.shot_clock += C.SHOT_INTERVAL
            self.shots.append(Bullet(self.px, self.py-10, 0, -C.SHOT_SPEED))
        for shot in self.shots:
            previous_y = shot.y
            shot.y += shot.vy*dt
            # 最初に当たる敵へ一回。高速度でも線分判定で抜けない。
            for enemy in sorted(self.enemies, key=lambda e: -e.y):
                if enemy.hp > 0 and segment_distance_sq(enemy.x, enemy.y,
                        (shot.x, previous_y), (shot.x, shot.y)) <= (enemy.radius+1)**2:
                    self.damage_enemy(enemy, C.SHOT_DAMAGE)
                    shot.y = -999
                    break
        self.shots = [b for b in self.shots if b.y > C.HUD_HEIGHT-8]
        live = []
        for b in self.bullets:
            previous = (b.x, b.y)
            b.x += b.vx*dt
            b.y += b.vy*dt
            if self.blade_hits_motion(previous, (b.x, b.y), C.BULLET_RADIUS):
                self.cleared_bullets += 1
                if sum(e.kind == "spark" for e in self.effects) < 24:
                    self.effects.append(Effect(b.x, b.y, "spark"))
                continue
            if segment_distance_sq(self.px, self.py, previous, (b.x, b.y)) <= (C.PLAYER_HIT_RADIUS+C.BULLET_HIT_RADIUS)**2:
                self.hurt()
                continue
            if -10 < b.x < C.WIDTH+10 and C.HUD_HEIGHT-20 < b.y < C.HEIGHT+12:
                live.append(b)
        self.bullets = live
        # 斬撃中も通常の接触判定。敵本体には16x16自機の外周で接触する。
        for e in self.enemies:
            nearest_x = max(self.px-8, min(self.px+8, e.x))
            nearest_y = max(self.py-8, min(self.py+8, e.y))
            if e.hp > 0 and math.hypot(e.x-nearest_x, e.y-nearest_y) < e.radius:
                self.hurt()
        self.enemies = [e for e in self.enemies if e.hp > 0 and -50 < e.y < C.HEIGHT+24]
        for effect in self.effects:
            effect.age += dt
        self.effects = [e for e in self.effects if e.age < (0.48 if e.kind == "split" else 0.22)]

    def schedule(self):
        for i, (time, xs) in enumerate(C.SMALL_WAVES):
            if self.time >= time and ("small", i) not in self.done:
                self.done.add(("small", i))
                for x in xs:
                    self.spawn("small", x)
        for i, (time, x) in enumerate(C.ARMOR_WAVES):
            if self.time >= time and ("armor", i) not in self.done:
                self.done.add(("armor", i))
                self.spawn("armor", x)

    def update_enemies(self, dt):
        for e in self.enemies:
            e.age += dt
            e.flash = max(0, e.flash-dt)
            if e.kind == "small":
                e.y += C.SMALL_SPEED*dt
                if e.age >= 2.0 and e.next_fire == 0:
                    self.fire(e, C.SMALL_BULLET_SPEED, (0,))
                    e.next_fire = 1
            elif e.age > C.ARMOR_LIFETIME:
                e.y -= C.ARMOR_ENTRY_SPEED*dt
            elif e.y < C.ARMOR_Y:
                e.y = min(C.ARMOR_Y, e.y+C.ARMOR_ENTRY_SPEED*dt)
            else:
                e.settled += dt
                phase = e.settled % (C.ARMOR_FIRE_SECONDS+C.ARMOR_REST_SECONDS)
                if phase < C.ARMOR_FIRE_SECONDS:
                    e.next_fire -= dt
                    if e.next_fire <= 1e-6:
                        spread = C.ARMOR_SPREAD_DEGREES
                        self.fire(e, C.ARMOR_BULLET_SPEED, (-spread, 0, spread))
                        e.next_fire += C.ARMOR_FIRE_INTERVAL
                else:
                    e.next_fire = 0

    def fire(self, e, speed, angles):
        aim = math.atan2(self.py-e.y, self.px-e.x)
        for offset in angles:
            a = aim+math.radians(offset)
            self.bullets.append(Bullet(e.x, e.y+e.radius, math.cos(a)*speed, math.sin(a)*speed))

    def blade_hits_motion(self, previous, current, radius):
        for poly, t0, t1 in self.slash_slices:
            def position(t):
                return (previous[0]+(current[0]-previous[0])*t,
                        previous[1]+(current[1]-previous[1])*t)
            if polygon_hits_motion(poly, position(t0), position(t1), radius):
                return True
        return False

    def update_blade(self, dt, previous_pivot=None, previous_enemies=None):
        # 毎フレーム破棄。振り始め・振り終わり・前フレームの残像には判定なし。
        self.slash_polys, self.slash_slices = [], []
        self.blade_pivot = (self.px, self.py-4)
        if self.swing < 0:
            self.blade_angle = -70
            return
        before = self.swing
        self.swing += dt
        wind, active = C.BLADE_WINDUP, C.BLADE_ACTIVE
        def angle(t):
            return C.BLADE_START_ANGLE+(C.BLADE_END_ANGLE-C.BLADE_START_ANGLE)*max(0, min(1, (t-wind)/active))
        if self.swing <= wind:
            self.blade_angle = -210+45*self.swing/wind
        elif min(self.swing, wind+active)-max(before, wind) > 1e-9:
            self.blade_angle = angle(self.swing)
            t0, t1 = (max(before, wind)-before)/dt, (min(self.swing, wind+active)-before)/dt
            current = (self.px, self.py-4)
            previous = previous_pivot if previous_pivot is not None else current
            def pivot(t):
                return (previous[0]+(current[0]-previous[0])*t,
                        previous[1]+(current[1]-previous[1])*t)
            self.slash_polys = sweep_polygons(*pivot(t1), angle(before), self.blade_angle, previous=pivot(t0))
            self.blade_pivot = pivot(t1)
            n = len(self.slash_polys)
            self.slash_slices = [(poly, t0+(t1-t0)*i/n, t0+(t1-t0)*(i+1)/n)
                                 for i, poly in enumerate(self.slash_polys)]
            for e in self.enemies:
                previous = (previous_enemies or {}).get(e.uid, (e.x, e.y))
                if e.hp > 0 and e.uid not in self.slash_hits and self.blade_hits_motion(previous, (e.x, e.y), e.radius):
                    self.slash_hits.add(e.uid)
                    self.damage_enemy(e, C.BLADE_DAMAGE, True)
        else:
            self.blade_angle = C.BLADE_END_ANGLE+45*min(1, (self.swing-wind-active)/C.BLADE_RECOVERY)
        if self.swing >= wind+active+C.BLADE_RECOVERY:
            self.swing = -1

    def hurt(self):
        if self.invincible > 0 or self.state != "playing":
            return
        self.hp -= 1
        self.invincible = C.INVINCIBLE_SECONDS
        self.events.append("hurt")
        self.effects.append(Effect(self.px, self.py, "hurt"))
        if self.hp <= 0:
            self.state = "gameover"
            self.events.append("over")
