# title: Blade Close Quarters
# version: 0.19.1
"""PC / GKD / Web共通入口。SELECTは状態・ヒットストップより先に処理。"""
import sys
import math
import json
import config as C
from game import Game, Actions
from view import View
from assets import load_resources
from audio import Audio
from persistence import BestStore


class Input:
    def __init__(self, p, profile="pc"):
        self.p, self.profile = p, profile
        mapping = C.GKD_INPUTS if profile == "gkd" else C.KEYBOARD_INPUTS
        self.keys = {name: tuple(getattr(p, k) if isinstance(k, str) else k for k in keys)
                     for name, keys in mapping.items()}
        self.bridge = None
        self.serials = {"slash": 0, "confirm": 0, "pause": 0, "focus": 0, "course": 0, "section": 0, "settings": 0, "weapon": 0, "touchMode": 0, "lab": 0, "inputReset": 0, "title":0,"retry":0,"nextStage":0,"continue":0,"menuPick":0}
        self.blocked = set()
        if sys.platform == "emscripten":
            from js import window
            self.bridge = window.bladeInput

    def read(self):
        held = {key for keys in self.keys.values() for key in keys if self.p.btn(key)}
        self.blocked.intersection_update(held)
        pulses, dx, dy, lost = set(), 0, 0, False
        if self.bridge is not None:
            b = self.bridge
            for name, previous in self.serials.items():
                current = int(getattr(b, name+"Serial", 0))
                if current != previous:
                    pulses.add(name)
                self.serials[name] = current
            lost = "focus" in pulses
            if lost:
                self.blocked.update(held)
            if ("inputReset" in pulses and
                    int(getattr(b,"slashSerial",0)) == int(getattr(b,"cancelSlashSerial",0))):
                pulses.discard("slash")
            # Only strings cross the JS -> Python boundary for relative movement.
            # A numeric JsProxy getter was observed returning the low int32 bits of a double.
            raw, packet, dx, dy, drag_reason = "", {}, 0.0, 0.0, "accepted"
            try:
                consume = getattr(b, "consumeDragJSON", None)
                if not callable(consume):
                    raise ValueError("Missing movement JSON protocol")
                raw = consume()
                if not isinstance(raw, str) or len(raw) > 1024:
                    raise ValueError("Invalid movement JSON text")
                packet = json.loads(raw)
                if (not isinstance(packet, dict) or packet.get("protocol") != 1 or
                        type(packet.get("seq")) is not int or packet["seq"] < 1 or
                        type(packet.get("x")) not in (int, float) or
                        type(packet.get("y")) not in (int, float) or
                        type(packet.get("suspended")) is not bool or
                        (packet.get("owner") is not None and type(packet["owner"]) is not int)):
                    raise ValueError("Invalid movement JSON schema")
                dx, dy = float(packet["x"]), float(packet["y"])
            except (ValueError, TypeError, OverflowError) as error:
                packet = {}
                drag_reason = "transport_error"
                if not getattr(self, "drag_protocol_error", False):
                    self.drag_protocol_error = True
                    if callable(getattr(b, "reportError", None)):
                        b.reportError("movement_transport", str(error), "")
            received_dx, received_dy = dx, dy
            # Keep both defenses unchanged; malformed transport never becomes movement.
            if not math.isfinite(dx) or not math.isfinite(dy):
                dx = dy = 0.0
                drag_reason = "nonfinite"
            elif math.hypot(dx, dy) > C.WEB_TOUCH["max_drag_frame_px"]:
                dx = dy = 0.0
                drag_reason = "frame_limit"
            elif drag_reason != "transport_error" and packet.get("owner") is None:
                dx = dy = 0.0
                drag_reason = "no_owner"
            if bool(b.suspended) or packet.get("suspended", False):
                held.clear()
                pulses.clear()
                dx = dy = 0.0
                drag_reason = "suspended"
            if bool(getattr(b, "touchDebugEnabled", False)) and callable(getattr(b, "reportReadJSON", None)):
                b.reportReadJSON(json.dumps({"received":[received_dx, received_dy], "out":[dx, dy],
                    "reason":drag_reason, "transport":"json-v1", "packetSeq":packet.get("seq"),
                    "wire":raw}, ensure_ascii=True))
        def down(name):
            return any(k in held and k not in self.blocked for k in self.keys[name])
        def pressed(name):
            return name in pulses or any(k in held and k not in self.blocked and self.p.btnp(k) for k in self.keys[name])
        return Actions(x=int(down("right"))-int(down("left")),
                       y=int(down("down"))-int(down("up")), drag_x=dx, drag_y=dy,
                       slash=pressed("slash"), confirm=pressed("confirm"), pause=pressed("pause"),
                       focus_lost=lost, quit=pressed("quit"), course="course" in pulses,section=int("section" in pulses),
                       settings=pressed("settings"),weapon=int("weapon" in pulses),
                       touch_mode=int("touchMode" in pulses),
                       lab=int(getattr(self.bridge,"labValue",2)) if "lab" in pulses else 0,title="title" in pulses,retry="retry" in pulses,next_stage="nextStage" in pulses,continue_run="continue" in pulses,
                       menu_pick=int(getattr(self.bridge,"menuPickValue",0)) if "menuPick" in pulses else 0)


class App:
    def __init__(self):
        import pyxel
        self.p = pyxel
        self.profile = "web" if sys.platform == "emscripten" else "gkd" if "--gkd" in sys.argv else "pc"
        course,section=self.options(sys.argv[1:])
        pyxel.init(C.WIDTH, C.HEIGHT, title=C.TITLE, fps=C.FPS, quit_key=pyxel.KEY_NONE)
        load_resources(pyxel)
        if "--attack-guides" in sys.argv:C.DEBUG_ATTACK_GUIDES=True
        if C.FULLSCREEN:
            pyxel.fullscreen(True)
        self.game, self.input, self.view = Game(course,section,self.seed_option(sys.argv[1:])), Input(pyxel, self.profile), View(pyxel, self.profile)
        if "--course" in sys.argv or "--section" in sys.argv:self.game.development=True
        self.store=BestStore(self.input.bridge)
        self.game.best_score=self.store.best
        if self.input.bridge is not None and callable(getattr(self.input.bridge,"reportBuild",None)):
            self.input.bridge.reportBuild(C.BUILD_ID)
        self.game.debug="--debug" in sys.argv or bool(getattr(self.input.bridge,"debug",False))
        for flag,attribute in (("--weapon","weapon"),("--touch-mode","touch_mode")):
            if flag in sys.argv:
                value=sys.argv[sys.argv.index(flag)+1]
                choices=C.WEAPONS if attribute=="weapon" else C.TOUCH_MODES
                if value not in choices:raise ValueError("Unknown "+flag)
                setattr(self.game,attribute,value)
                if attribute=="weapon":self.game.selected_weapon=value
        if "--story-preview" in sys.argv:
            i=sys.argv.index("--story-preview")
            if i+1>=len(sys.argv):raise ValueError("Missing value for --story-preview")
            self.game.preview_story(sys.argv[i+1])
        self.audio = Audio(pyxel)
        pyxel.run(self.update, self.draw)

    @staticmethod
    def seed_option(args):
        if "--seed" not in args:return None
        i=args.index("--seed")
        if i+1>=len(args):raise ValueError("Missing value for --seed")
        return int(args[i+1])

    @staticmethod
    def options(args):
        course,section=C.DEFAULT_COURSE,0
        for i,arg in enumerate(args):
            if arg in ("--course","--section") and i+1>=len(args):raise ValueError("Missing value for "+arg)
            if arg=="--course":course=args[i+1]
            elif arg=="--section":section=int(args[i+1])-1
        if course not in C.COURSES:raise ValueError("Unknown course: "+course)
        if not 0<=section<len(C.COURSES[course]["sections"]):raise ValueError("Section number outside course")
        return course,section

    def report_error(self,source):
        import traceback
        bridge=self.input.bridge
        if bridge is not None and callable(getattr(bridge,"reportError",None)):
            try:bridge.reportError("Python:"+source,str(sys.exc_info()[1]),traceback.format_exc())
            except Exception:pass

    def update(self):
        try:self.update_frame()
        except Exception:
            self.report_error("update")
            raise

    def update_frame(self):
        action = self.input.read()
        if action.quit:
            self.p.quit()
            return
        previous_state=self.game.state
        previous_story_revision=self.game.story_revision
        previous_position=(self.game.px,self.game.py)
        previous_hitstop=self.game.hitstop
        self.game.touch_trace_enabled=bool(getattr(self.input.bridge,"touchDebugEnabled",False))
        self.game.step(1/C.FPS, action)
        if self.game.result is not None:self.store.save(self.game.best_score)
        self.game.save_failed=self.store.failed
        if previous_state!=self.game.state or previous_story_revision!=self.game.story_revision:
            # 画面遷移で物理キーの保持も持ち越さず、離してから再入力する。
            self.input.blocked.update(k for keys in self.input.keys.values() for k in keys if self.p.btn(k))
        if self.input.bridge is not None:
            bridge=self.input.bridge
            if "life_lost" in self.game.events:
                # Rebase only existing owners; keep scene/background resets fully destructive.
                reset = getattr(bridge, "rebaseTouch", None) or getattr(bridge, "resetTouch", None)
                if callable(reset):reset("respawn")
            if (self.game.debug or self.game.touch_trace_enabled) and callable(getattr(bridge,"recordPlayer",None)):
                bridge.recordPlayer(self.game.px,self.game.py,self.game.state,self.game.time,
                                    self.game.last_position_reason,action.drag_x,action.drag_y,*previous_position,
                                    json.dumps(self.game.position_writes),
                                    "hitstop" if previous_hitstop>0 else self.game.state)
            self.input.bridge.canContinue=self.game.can_continue
            self.input.bridge.playMode=self.game.play_mode
            self.input.bridge.stageNumber = self.game.run.current_stage
            self.input.bridge.canAdvanceStage = self.game.can_advance_stage
            self.input.bridge.state = self.game.state
            self.input.bridge.storyRevision = self.game.story_revision
            self.input.bridge.meleeReady = self.game.state=="playing" and self.game.cooldown<=1e-6 and self.game.swing<0
            self.input.bridge.weapon = self.game.weapon
            self.input.bridge.touchMode = self.game.touch_mode
            self.input.bridge.labMode = self.game.lab_mode
            self.input.bridge.course = self.game.course
            self.input.bridge.courseLabel = self.game.course_config["menu_label"]
            self.input.bridge.sectionLabel = ("最初から" if self.game.checkpoint==0 else
                                            self.game.course_config["sections"][self.game.checkpoint][1])
        self.audio.update(self.game)

    def draw(self):
        try:self.view.draw(self.game)
        except Exception:
            self.report_error("draw")
            raise


if __name__ == "__main__":
    App()
